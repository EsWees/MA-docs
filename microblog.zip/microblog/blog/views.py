from django.shortcuts import render, redirect, reverse
from django.views.generic import View, ListView

from .models import Post
from .forms import PostForm


# Create your views here.
# def start_blog(request):
#     return render(request, 'blog/base_blog.html')


def posts_list(request):
    posts = Post.objects.all().order_by('-publish')
    return render(request, 'blog/base_blog.html', context={'posts': posts})


# def post_detail(request, slug):
#     post = Post.objects.get(slug__iexact=slug)
#     return render(request, 'blog/post_detail.html', context={'post': post})


class PostDetail(View):
    def get(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        return render(request, 'blog/post_detail.html', context={'post': post})


def post_create(request):
    if request.method == 'POST':
        post = Post.objects.create(title=request.POST['title'],
                                   slug=request.POST['slug'],
                                   body=request.POST['body'])
        return render(request, 'blog/post_detail.html', context={'post': post})
    return render(request, 'blog/add_entry.html')


class PostCreate(View):

    def get(self, request):
        form = PostForm()
        return render(request, 'blog/post_create.html', context={'form': form})

    def post(self, request):
        bound_form = PostForm(request.POST)

        if bound_form.is_valid():
            new_post = bound_form.save()
            return redirect(new_post)
        return render(request, 'blog/post_create.html', context={'form': bound_form})


class PostUpdate(View):

    def get(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        bound_form = PostForm(instance=post)  # instance=post
        # bound_form = PostForm({'title': post.title, 'slug': post.slug, 'body': post.body})
        return render(request, 'blog/post_update.html', context={'form': bound_form, 'post': post})

    def post(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        bound_form = PostForm(request.POST, instance=post)

        if bound_form.is_valid():
            new_post = bound_form.save()
            return redirect(new_post)
        return render(request, 'blog/post_update.html', context={'form': bound_form, 'post': post})


class PostDelete(View):

    def get(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        bound_form = PostForm(instance=post)  # instance=post
        # bound_form = PostForm({'title': post.title, 'slug': post.slug, 'body': post.body})
        return render(request, 'blog/post_delete.html', context={'form': bound_form, 'post': post})

    def post(self, request, slug):
        post = Post.objects.get(slug__iexact=slug)
        post.delete()
        return redirect(reverse('posts_list_url'))
    

class PostListView(ListView):
    queryset = Post.objects.all().order_by('-publish')
    context_object_name = 'posts'
    paginate_by = 3
    template_name = 'blog/base_blog.html'

