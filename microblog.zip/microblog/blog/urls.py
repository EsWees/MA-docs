from django.urls import path, include
from .views import posts_list, post_create  #, post_detail
from .views import PostDetail, PostCreate, PostUpdate, PostDelete, PostListView


urlpatterns = [
    # path('', posts_list, name='posts_list_url'),
    path('', PostListView.as_view(), name='post_pagin_list_url'),
    # path('post/create/', post_create, name='post_create_url'),
    path('post/create/', PostCreate.as_view(), name='post_create_url'),
    # path('post/<str:slug>', post_detail, name='post_detail_url'),
    path('post/<str:slug>', PostDetail.as_view(), name='post_detail_url'),
    path('post/<str:slug>/update/', PostUpdate.as_view(), name='post_update_url'),
    path('post/<str:slug>/delete/', PostDelete.as_view(), name='post_delete_url'),

    # path('admin/', admin.site.urls),
]
